#(c) MisterL2 2019

from .haskell import *
from .general import *
from .math import *
from .files import *
from .data_structures import *
